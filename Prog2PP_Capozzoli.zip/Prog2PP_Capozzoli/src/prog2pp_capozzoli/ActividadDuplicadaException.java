/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2pp_capozzoli;

/**
 *
 * @author xmamb
 */
public class ActividadDuplicadaException extends Exception {
    public static final String MESSAGE = "Ya existe una actividad con el mismo nombre y entrenador";
    
    public ActividadDuplicadaException(){
        this(MESSAGE);
    }
    
    public ActividadDuplicadaException(String mensaje){
        super(mensaje);
    }
}
