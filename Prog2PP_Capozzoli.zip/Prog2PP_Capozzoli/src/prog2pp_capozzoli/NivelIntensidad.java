/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2pp_capozzoli;

/**
 *
 * @author xmamb
 */
public enum NivelIntensidad {
    
    BAJA,
    MEDIA,
    ALTA
    
}
