/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package capozzolipaularecppprogii321;

/**
 *
 * @author Capozzoli Paula
 */
public class ArchivoDuplicadoException extends Exception{
    public static final String MESSAGE = "Ya existe un archivo con el mismo código y que corresponde a la misma agencia responsable";
    
    public ArchivoDuplicadoException(){
        this(MESSAGE);
    }
    
    public ArchivoDuplicadoException(String mensaje){
        super(mensaje);
    }
}
