/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2pp_capozzoli;

import java.util.Objects;

/**
 * Representa a una clase grupal del centro de entrenamiento
 * Incorpora un máximo de participantes por clase
 * @author Paula Capozzoli
 */
public class ClaseGrupal extends Actividad implements Programable{
    private final int maxParticipantes;
    
    public ClaseGrupal (String nombre, String entrenadorResponsable, NivelIntensidad nivel, int maxParticipantes){
        super(nombre, entrenadorResponsable, nivel);
        validarParticipantes(maxParticipantes);
        this.maxParticipantes = maxParticipantes;
    }
    
    private void validarParticipantes(int participantes){
        if(participantes <=0){
            throw new IllegalArgumentException("La cantidad de participantes debe ser mayor a 0");
        }
    }
    
    public int getMaxParticipantes(){
        return maxParticipantes;
    }
    
    @Override
    public String getDescripcion(){        
        return "ClaseGrupal [nombre="+ getNombre()+
               ", entrenador="+ getEntrenadorResponsable()+
               ", intensidad="+ getNivelIntensidad()+
               ", maxParticipantes="+ maxParticipantes+"]";        
    }
    
    @Override
    public String programar(){
        return "Se programo la clase grupal: "+ getNombre();
    }
    
}
