/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package capozzolipaularecppprogii321;

/**
 * Representa archivos del tipo Evaluacion Tecnica
 * es abstracta porque existen dos tipos de evaluaciones
 * @author Capozzoli Paula
 */
public abstract class EvidenciaTecnica extends Archivo{
    private final String fechaObtencion;
    
    public EvidenciaTecnica(String codigo, String agenciaResponsable, NivelClasificacion nivel,)
}
