/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2pp_capozzoli;

import java.util.Objects;

/**
 * Representa una actividad del centro de entrenamiento
 * 
 * Tiene nombre, entrenador responsable y nivel de intensidad
 * Clase abstracta porque se registran distintos tipos de 
 * actividades concretas 
 * @author Paula Capozzoli
 */
public abstract class Actividad {
    private final String nombre;
    private final String entrenadorResponsable;
    private final NivelIntensidad nivelIntensidad;
    
    public Actividad(String nombre, String entrenadorResponsable, NivelIntensidad nivel){
        validarString(nombre, "El nombre de la actividad no puede estar vacío");
        validarString(entrenadorResponsable, "El nombre del entrenador no puede estar vacío");
        validarNivel(nivel); 
        
        this.nombre=nombre;
        this.entrenadorResponsable=entrenadorResponsable;
        this.nivelIntensidad= nivel;
    }
    
    private void validarString(String string, String mensaje){
        if (string == null || string.isBlank()){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    private void validarNivel(NivelIntensidad nivel){
        if (nivel == null){
            throw new IllegalArgumentException("El nivel de intensidad no puede ser nulo(null)");
        }
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getEntrenadorResponsable(){
        return entrenadorResponsable;
    }
    
    public NivelIntensidad getNivelIntensidad(){
        return nivelIntensidad;
    }
    
    public abstract String getDescripcion();
    
    @Override
    public String toString(){
        return getDescripcion();
    }
    
    @Override
    public boolean equals(Object objeto){
        if(this == objeto){
            return true;
        }
        if (!(objeto instanceof Actividad distinta)){
            return false;
        }
        return nombre.equals(distinta.nombre)&&entrenadorResponsable.equals(distinta.entrenadorResponsable);
    }
    @Override
    public int hashCode(){
        return Objects.hash(nombre, entrenadorResponsable);
    }
    
    
}
