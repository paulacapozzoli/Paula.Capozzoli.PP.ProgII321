/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2pp_capozzoli;

/**
 * Representa a una evaluación física del centro de entrenamiento
 * Incorpora un puntaje del 0/100
 * @author Paula Capozzoli
 */
public class EvaluacionFisica extends Actividad implements Informable{
   private static final int PUNTAJE_MIN = 0;
   private static final int PUNTAJE_MAX = 100;
   private final int puntaje;
   
   public EvaluacionFisica(String nombre, String entrenadorResponsable, NivelIntensidad nivel, int puntaje){
       super(nombre, entrenadorResponsable, nivel);
       validarPuntaje(puntaje);
       this.puntaje = puntaje;
   }
   
   private void validarPuntaje(int puntaje){
       if(puntaje < PUNTAJE_MIN || puntaje > PUNTAJE_MAX){
           throw new IllegalArgumentException("El puntaje debe estar en el rango de "+ PUNTAJE_MIN +" a "+ PUNTAJE_MAX);
       }
   }
   
   public int getPuntaje(){
       return puntaje;
   }
   
   @Override
   public String generarInforme(){
       return "Informe de evaluacion fisica: "+ getNombre() +
               ". Puntaje obtenido: "+ getPuntaje() +
               "/"+ PUNTAJE_MAX;
   }
   
   @Override
   public String getDescripcion(){
       return "EvaluacionFisica [nombre="+ getNombre()+
               ", entrenador="+ getEntrenadorResponsable()+
               ", intensidad="+ getNivelIntensidad()+
               ", puntaje="+ puntaje +"]";
   }
   
}
