package capozzolipaularecppprogii321;

import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Capozzoli Paula
 */
public class ArchivoDesclasificado {
   private final String nombre;
   private final List<Archivo> archivos;
   
   public ArchivoDesclasificado(String nombre){
       validarNombre(nombre);
             this.nombre = nombre;
             archivos = new ArrayList<>();
   }
   
   private void validarNombre(String nombre){
       if(nombre == null || nombre.isBlank()){
           throw new IllegalArgumentException("El nombre del archivo desclasificado no puede estar vacío");
       }
       
   }
   public String getNombre(){
       return nombre;
   }
   
   /**
     * Agrega un Archivo.
     * Se considera repetido al que tenga mismo código y pertenezca a la misma agencia
     * se comparan con un equals de la clase Archivo
     * @param archivo
     * @throws ArchivoDuplicadoException por si ya existe
     * un archivo con mismo codigo y agencia
     * @author Paula Capozzoli
     */
    public void agregarArchivo(Archivo archivo) throws ArchivoDuplicadoException {
        validarArchivo(archivo);
        validarArchivoRepetido(archivo);
        archivos.add(archivo);
    }
    
    public void validarArchivo(Archivo archivo){
        if(archivo == null){
            throws new IllegalArgumentException("El archivo no puede ser null")
        }
    }
    
    private void validarArchivoRepetido(Archivo archivo) throws ArchivoDuplicadoException {
        if(archivos.contains(archivo)){
            throw new ArchivoDuplicadoException("Ya existe un archivo con codigo '" +
                      archivo.getCodigo() +"' perteneciente a la agencia '" + 
                      archivo.getAgenciaResponsable()+"'." )
        }
    }
    
    public List<Archivo> obtenerArchivos(){
        return new ArrayList<>(archivos);
    }
    
    public List<Archivo> filtrarPorClasificacion(NivelClasificacion nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel de clasificacion del archivo no puede ser null")
        }
        List<Archivo> filtrados = new ArrayList<>();
        
        for(Archivo archivo : archivos){
            if(archivo.getNivelClasificacion() == nivel){
                filtrados.add(archivo);
            }
        }
        return filtrados;
    }
}
