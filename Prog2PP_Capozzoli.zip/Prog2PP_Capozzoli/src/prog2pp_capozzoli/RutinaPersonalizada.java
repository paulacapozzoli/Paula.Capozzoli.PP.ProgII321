/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2pp_capozzoli;

/**
 * Representa a una rutina personalizada del centro de entrenamiento
 * Incorpora la duración de la rutina en semanas
 * @author Paula Capozzoli
 */
public class RutinaPersonalizada extends Actividad implements Programable, Informable{
    private final int duracionSemanas;
    
    public RutinaPersonalizada(String nombre, String entrenadorResponsable, NivelIntensidad nivel, int duracion){
        super(nombre, entrenadorResponsable, nivel);
        validarDuracion(duracion);
        this.duracionSemanas = duracion;
    }
    
    private void validarDuracion(int duracion){
        if(duracion <= 0){
            throw new IllegalArgumentException("La duración debe ser mayor a 0");
        }
    }
    
    public int getDuracionSemanas(){
        return duracionSemanas;
    }
    
    @Override
    public String getDescripcion(){
        return "RutinaPersonalizada [nombre="+ getNombre()+
               ", entrenador="+ getEntrenadorResponsable()+
               ", intensidad="+ getNivelIntensidad()+
               ", duracionSemanas="+ duracionSemanas+"]";
    }
    
    @Override
    public String programar(){
        return "Se programo la rutina personalizada: "+ getNombre();
    }
    
    @Override
    public String generarInforme(){
        return "Informe de rutina personalizada: "+ getNombre()+
               ". Duracion estimada: "+ getDuracionSemanas()+
               " semanas";
    }
}
