/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package capozzolipaularecppprogii321;

/**
 *
 * @author Capozzoli Paula
 */
public enum NivelClasificacion {
    PUBLICO,
    RESERVADO,
    ULTRASECRETO
    
}
