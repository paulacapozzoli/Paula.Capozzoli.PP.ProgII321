/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2pp_capozzoli;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa un centro de entrenamiento
 * Maneja una colección de actividades, algunas son programables y otras 
 * generan informes. Se pueden filtrar por intensidad.
 * @author Paula Capozzoli
 */
public class CentroEntrenamiento {
    
    private final String nombre;
    private final List<Actividad> actividades;
    
    public CentroEntrenamiento(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        actividades = new ArrayList<>();
    }
    
    private void validarNombre(String nombre){
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre del centro no puede estar vacío");
        }
    }
    
    public String getNombre(){
        return nombre;
    }
    /**
     * Agrega una actividad.
     * Si tienen el mismo nombre y entrenador son repetidas,
     * se comparan con un equals de la clase Actividad
     * @param actividad
     * @throws ActividadDuplicadaException por si ya existe
     * una actividad en el centro
     * @author Paula Capozzoli
     */
    public void agregarActividad(Actividad actividad) throws ActividadDuplicadaException {
        validarActividad(actividad);
        validarActividadRepetida(actividad);
        actividades.add(actividad);
    }
    
    private void validarActividad(Actividad actividad){
        if(actividad == null){
            throw new IllegalArgumentException("La actividad no puede ser nula(null)");
        }
    }
    
    private void validarActividadRepetida(Actividad actividad) throws ActividadDuplicadaException {
        if(actividades.contains(actividad)){
            throw new ActividadDuplicadaException("Ya existe una actividad con nombre '" +
                      actividad.getNombre() +"' y entrenador '" + 
                      actividad.getEntrenadorResponsable()+"'." );
        }
    }
    
    public List<Actividad> obtenerActividades(){
        return new ArrayList<>(actividades);
    }
    
    /**
     * Trae las actividades filtradas según nivel de intensidad que recibe
     * @param nivel es el nivel de intensidad que uso de filtro
     * @return trae actividades que coincidan con el nivel recibido
     */
    public List<Actividad> filtrarPorNivel(NivelIntensidad nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel de actividad no puede ser nulo(null)");
        }
        List<Actividad> filtradas = new ArrayList<>();
        
        for(Actividad actividad : actividades){
            if(actividad.getNivelIntensidad() == nivel){
                filtradas.add(actividad);
            }
        }
        return filtradas;
    }    
    
    
    
    
}
