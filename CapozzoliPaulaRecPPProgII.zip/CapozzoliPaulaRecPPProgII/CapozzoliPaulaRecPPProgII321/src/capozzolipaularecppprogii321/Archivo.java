/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package capozzolipaularecppprogii321;
import java.util.Objects;

/**
 * Representa un archivo(documento) de un archivo desclasificado
 * 
 * Tiene codigo, agencia responsable y nivel de clasificacion
 * Clase abstracta porque se registran distintos tipos de 
 * archivos concretos
 * @author Capozzoli Paula
 */
public abstract class Archivo {
    private final String codigo;
    private final String agenciaResponsable;
    private final NivelClasificacion nivelClasificacion;
    
    public Archivo(String codigo, String agenciaResponsable, NivelClasificacion nivel){
        validarString(codigo, "El codigo del archivo no puede estar vacío");
        validarString(agenciaResponsable, "El codigo de la agencia no puede estar vacío");
        validarNivel(nivel);
                
        this.codigo=codigo;
        this.agenciaResponsable=agenciaResponsable;
        this.nivelClasificacion=nivel;                
    }
    
    private void validarString(String string, String mensaje){
        if (string == null || string.isBlank()){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    private void validarNivel(NivelClasificacion nivel){
        if (nivel == null){
            throw new IllegalArgumentException("El nivel de clasificacion no puede ser null");
        }
    }
    
    public String getCodigo(){
        return codigo;
    }
    
    public String getAgenciaResponsable(){
        return agenciaResponsable;
    }
    
    public NivelClasificacion getNivelClasificacion(){
        return nivelClasificacion;
    }
    
    public abstract String getDescripcion();
    
    @Override
    public String toString(){
        return getDescripcion();
    }
    
    @Override
    public boolean equals(Object objeto){
        if(this == objeto){
            return true;
        }
        if (!(objeto instanceof Archivo distinto)){
            return false;
        }
        return codigo.equals(distinto.codigo)&&agenciaResponsable.equals(distinto.agenciaResponsable);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(codigo, agenciaResponsable);
    }
    
            
}
